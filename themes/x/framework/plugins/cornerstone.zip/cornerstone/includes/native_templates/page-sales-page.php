<?php return array (
  'title' => 'Sales Page',
  'elements' =>
  array (
    0 =>
    array (
      'elType' => 'section',
      'title' => 'Introduction',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Introduction',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'line',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '7%',
            2 => '0px',
            3 => '7%',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffffff',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#e5e5e5',
      'border' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    1 =>
    array (
      'elType' => 'section',
      'title' => 'Alternating Features',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '2/3 + 1/3',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '2/3',
              'title' => '2/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/750x400/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '20px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Summary',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0 0 0.15em;',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'text',
                  'content' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Highlights',
                  'level' => 'h4',
                  'looks_like' => 'h5',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 1.25em 0 0.35em;',
                  'text_align' => 'none',
                ),
                3 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Feature One',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Feature Two',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Feature Three',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/3 + 2/3',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Summary',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0 0 0.15em;',
                  'title' => 'Copy of undefined',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'text',
                  'content' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Highlights',
                  'level' => 'h4',
                  'looks_like' => 'h5',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 1.25em 0 0.35em;',
                  'title' => 'Copy of undefined',
                  'text_align' => 'none',
                ),
                3 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Feature One',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Feature Two',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Feature Three',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '20px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '2/3',
              'title' => '2/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/750x400/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        2 =>
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 1',
          'columnLayout' => '2/3 + 1/3',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '2/3',
              'title' => '2/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/750x400/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '20px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Summary',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0 0 0.15em;',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'text',
                  'content' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Highlights',
                  'level' => 'h4',
                  'looks_like' => 'h5',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 1.25em 0 0.35em;',
                  'text_align' => 'none',
                ),
                3 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Feature One',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Feature Two',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Feature Three',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#fafafa',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'unlinked',
      ),
      'text_align' => 'none',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    2 =>
    array (
      'elType' => 'section',
      'title' => 'Attention Getter',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Look at me! I catch peoples\' attention nicely.',
                  'level' => 'h5',
                  'looks_like' => 'h4',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffff00',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#ebeb00',
      'border' =>
      array (
        0 => '1px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    3 =>
    array (
      'elType' => 'section',
      'title' => 'Centered Feature',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Feature Section',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'line',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'none',
                  'float' => 'none',
                  'src' => 'http://placehold.it/500x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffffff',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#e5e5e5',
      'border' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    4 =>
    array (
      'elType' => 'section',
      'title' => 'Feature Columns',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'More Features',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'line',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 3',
          'columnLayout' => '1/6 + 1/6 + 1/6 + 1/6 + 1/6 + 1/6',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/6',
              'title' => '1/6',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'thumbnail',
                  'float' => 'none',
                  'src' => 'http://placehold.it/150x150/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        2 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#fafafa',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    5 =>
    array (
      'elType' => 'section',
      'title' => 'Attention Getter',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'text-type',
                  'prefix' => 'I\'m back! Aren\'t you ',
                  'strings' => 'amazed
impressed
intrigued',
                  'suffix' => ' by my typing skills?',
                  'tag' => 'h5',
                  'type_speed' => 50,
                  'start_delay' => 0,
                  'back_speed' => 50,
                  'back_delay' => 3000,
                  'loop' => true,
                  'show_cursor' => true,
                  'cursor' => '|',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'looks_like' => 'h4',
                  'text_align' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffff00',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#ebeb00',
      'border' =>
      array (
        0 => '1px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    6 =>
    array (
      'elType' => 'section',
      'title' => 'Dark Feature Columns',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Even More Features',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => 'color: #fff;',
                  'text_align' => 'none',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '30px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '5%',
            2 => '0px',
            3 => '5%',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 2',
          'columnLayout' => '1/4 + 1/4 + 1/4 + 1/4',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '30px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        2 =>
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 3',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man" style="color: #656565">[icon type="thumbs-up"] Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '75px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        3 =>
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 1',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'And Even More Features',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => 'color: #fff;',
                  'text_align' => 'none',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '30px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '5%',
            2 => '0px',
            3 => '5%',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        4 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/4 + 1/4 + 1/4 + 1/4',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/4',
              'title' => '1/4',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/300x300/454545/272727',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '30px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        5 =>
        array (
          'elType' => 'row',
          'title' => 'Row 3',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man" style="color: #656565">[icon type="thumbs-up"] Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#272727',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    7 =>
    array (
      'elType' => 'section',
      'title' => 'Attention Getter',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'I\'m back! You just can\'t get rid of me. [icon type="smile-o"]',
                  'level' => 'h5',
                  'looks_like' => 'h4',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffff00',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#ebeb00',
      'border' =>
      array (
        0 => '1px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    8 =>
    array (
      'elType' => 'section',
      'title' => 'Two Column Features',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/2 + 1/2',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                5 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                6 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                7 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                8 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of Copy of undefined',
                ),
                9 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of Copy of undefined',
                ),
                5 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                6 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of Copy of undefined',
                ),
                7 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                8 =>
                array (
                  'elType' => 'image',
                  'image_style' => 'rounded',
                  'float' => 'none',
                  'src' => 'http://placehold.it/600x275/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'link' => false,
                  'href' => '#',
                  'href_title' => '',
                  'href_target' => false,
                  'info' => 'none',
                  'info_place' => 'top',
                  'info_trigger' => 'hover',
                  'info_content' => '',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#fafafa',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'solid',
      'border_color' => '#e5e5e5',
      'border' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '1px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
    9 =>
    array (
      'elType' => 'section',
      'title' => 'Marginless Columns',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Marginless Columns',
                  'level' => 'h2',
                  'looks_like' => 'h2',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'line',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/3 + 1/3 + 1/3',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '#f5f5f5',
              'padding' =>
              array (
                0 => '5%',
                1 => '5%',
                2 => '5%',
                3 => '5%',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'One',
                  'level' => 'h2',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Icon List Item 1',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Icon List Item 2',
                      'type' => 'remove',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Icon List Item 3',
                      'type' => 'remove',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                ),
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '#e5e5e5',
              'padding' =>
              array (
                0 => '5%',
                1 => '5%',
                2 => '5%',
                3 => '5%',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Two',
                  'level' => 'h2',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Icon List Item 1',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Icon List Item 2',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Icon List Item 3',
                      'type' => 'remove',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '#d5d5d5',
              'padding' =>
              array (
                0 => '5%',
                1 => '5%',
                2 => '5%',
                3 => '5%',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Three',
                  'level' => 'h2',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '15px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                4 =>
                array (
                  'elType' => 'icon-list',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'title' => 'Icon List Item 1',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    1 =>
                    array (
                      'title' => 'Icon List Item 2',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                    2 =>
                    array (
                      'title' => 'Icon List Item 3',
                      'type' => 'check',
                      'elType' => 'icon-list-item',
                      'custom_id' => '',
                      'class' => '',
                      'style' => '',
                    ),
                  ),
                  'childType' => 'icon-list-item',
                  'custom_id' => '',
                  'class' => 'mvn',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'unlinked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => false,
          'marginless_columns' => true,
          'bg_color' => '',
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffffff',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '0',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'center-text',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
  ),
);